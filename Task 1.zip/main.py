import csv
import svgwrite
import networkx as nx
import matplotlib.pyplot as plt

from lxml import etree

map = etree.parse('map.osm')

result = {}
nodes = {}

bounds = map.find('/bounds')

minlat = float(bounds.get('minlat'))
maxlat = float(bounds.get('maxlat'))
minlon = float(bounds.get('minlon'))
maxlon = float(bounds.get('maxlon'))

for node in map.iterfind('/node'):
    nodes[node.get('id')] = [float(node.get('lon')),float(node.get('lat'))]

for highway in map.iterfind('/way/tag[@k = "highway"]'):

    if highway.get('v') in ['motorway', 'trunk', 'primary', 'secondary', 'tertiary', 'unclassified', 'residential', 'living_street']:
        
        buffer = None
        
        for next_node in highway.iterfind('../nd'):

                if buffer is None:
                    buffer = next_node

                else:
                    for tag in highway.iterfind('../tag'):

                        if tag.get('k') == 'oneway' and tag.get('v') == 'yes':
                            if buffer.get('ref') not in result:
                                result[buffer.get('ref')] = set()

                            result[buffer.get('ref')].add(next_node.get('ref'))
                            buffer = next_node

                    else:

                        if buffer.get('ref') not in result:
                            result[buffer.get('ref')] = set()

                        if next_node.get('ref') not in result:
                            result[next_node.get('ref')] = set()

                        result[buffer.get('ref')].add(next_node.get('ref'))
                        result[next_node.get('ref')].add(buffer.get('ref'))
                        buffer = next_node

# Граф дорог
node_array = [] 
n = 0 
var = '' 
for i in result: 
    node_array.append(i + ' ') 
    for a in result[i]: 
        var = str(node_array[n])   
        var = var + a + ' ' 
        node_array[n] = var 

    n = n + 1 

the_file = open('test.txt', 'w') 
for item in node_array: 
    the_file.write('%s\n' % item) 
 
G = nx.read_adjlist('test.txt') 
nx.draw(G, pos = nodes, node_size = 0, width = 0.05) 
plt.axis('off') 
plt.savefig("graph.svg", dpi = 3000, figsize = (10,15)) 

# Вывод списка смежности
with open('list.csv', 'w') as file:
        csv.writer(file).writerows(result.items())

# Вывод матрицы смежности
with open('matrix.csv', 'w') as file:

    csv.writer(file).writerow(list(result.keys()))

    for row_1 in result:
        matrix_row = []
        for row_2 in result:
            if row_2 in result[row_1]:
                matrix_row.append(1)
            else:
                matrix_row.append(0)
        csv.writer(file).writerow([row_1] + list(matrix_row))
